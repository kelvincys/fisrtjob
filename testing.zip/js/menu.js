$(window).ready(function() {
    $('#img1').hover(
        function() {
            $('#img1').fadeIn('slow');
        },function() {
            $('#img1').fadeOut('slow');
        }
    );

    $('#img2').hover(
        function() {
            $('#img2').fadeIn('slow');
        },function() {
            $('#img2').fadeOut('slow');
        }
    );

    $('#img3').hover(
        function() {
            $('#img3').fadeIn('slow');
        },function() {
            $('#img3').fadeOut('slow');
        }
    );
});